package cc.mrbird.febs.salm.dao;

import cc.mrbird.febs.salm.entity.CustomerInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author FanK
 */
public interface CustomerInfoMapper extends BaseMapper<CustomerInfo> {

}
