package cc.mrbird.febs.salm.service;

import cc.mrbird.febs.salm.entity.CustomerInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @author FanK
 */
public interface ICustomerInfoService extends IService<CustomerInfo> {

}
